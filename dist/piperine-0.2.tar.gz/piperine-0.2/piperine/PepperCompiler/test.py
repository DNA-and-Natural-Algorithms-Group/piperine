import unittest

import utils
utils.DEBUG = True

from tests import *

if __name__ == '__main__':
  unittest.main()

